'use strict';

var AWS = require('aws-sdk');
const uuid = require('uuid');
var PROMISE = require("bluebird");
const USERTABLE = 'user';
const LISTINGTABLE = "listing";
const TASKTABLE = "task";



function validation(event) {
    var response = {};
    var key = 'Error';
    response[key] = [];

    var re = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (event.username === "") {
        response[key].push({ username: 'Username should not be empty' });
    }
    if (event.password === "") {
        response[key].push({ password: 'Password should not be empty' });
    }
    if (event.firstname === "") {
        response[key].push({ firstname: 'First Name should not be empty' });
    }
    if (event.secondname === "") {
        response[key].push({ secondname: 'Last Name should not be empty' });
    }
    if (event.email === "") {
        response[key].push({ email: 'Email should not be empty' });
    }
    else if (!re.test(event.email)) {
        response[key].push({ email: 'Email is not valid' });
    }
    return response;
}

function sortByKey(array, key) {
    return array.sort(function (a, b) {
        var x = a[key]; var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
}

module.exports.register = (event, context, callback) => {

    var postdata = event['body'];

    var response = validation(postdata)

    if (response.Error.length > 0) {
        callback(null, response);
        return;
    }

    var docClient = new AWS.DynamoDB.DocumentClient();

    var params = {
        TableName: USERTABLE
    }

    docClient.scan(params, onScan);

    function onScan(err, itemCollection) {
        if (err) {

            console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));

        } else {

            var totalrecords = itemCollection.Items.length;
            var last_id = 0
            var new_id;
            if (totalrecords > 0) {
                // print all the movies
                console.log("Scanning DONE.");
                var useritems = sortByKey(itemCollection.Items, 'user_id');
                //console.log(useritems);

                var lastitem = useritems.pop()
                last_id = lastitem.user_id
            }
            new_id = last_id + 1


            var item = {
                'user_id': new_id,
            };

            for (var attributename in postdata) {
                if (postdata[attributename].length > 0) {
                    //console.log(attributename+": "+postdata[attributename]);
                    item[attributename] = [];
                    item[attributename] = postdata[attributename]
                }
            }

            //Put Item to DynamoDB
            console.log("Adding a new item...");

            var params = {
                TableName: USERTABLE,
                Item: item
            };

            docClient.put(params, function (err, data) {
                if (err) {
                    console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
                    response = {
                        Error: 'Data is not saved successfully'
                    }
                    callback(null, JSON.stringify(response));
                    return;

                } else {
                    console.log("Added item:", JSON.stringify(item, null, 2));
                    response = {
                        status_code: 200,
                        message: 'Data is saved successfully'
                    }
                    callback(null, JSON.stringify(response));
                    return;
                }
            });
        }
    }
};

module.exports.updatePassword = (event, context, callback) => {
    var postdata = event['body'];
    var username = postdata["username"];
    var password = postdata["password"];

    if (username != '' && username != null) {
        var dynamodb = new AWS.DynamoDB();
        var docClient = new AWS.DynamoDB.DocumentClient();

        var params = {
            TableName: USERTABLE,
            FilterExpression: "username = :u",
            ExpressionAttributeValues: {
                ":u": username
            }
        }

        docClient.scan(params, function (err, data) {
            if (err) {
                console.log("Unable to query. Error:", JSON.stringify(err, null, 2));
                console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
            } else {
                if (data.Items.length > 0) {
                    console.log("Result:", JSON.stringify(data.Items.length, null, 2));
                    var user_id = data.Items[0].user_id;
                    var updateParams = {
                        TableName: USERTABLE,
                        Key: {
                            "user_id": parseInt(user_id)
                        },
                        UpdateExpression: "set #password = :password",
                        ExpressionAttributeValues: { ":password": password },
                        ExpressionAttributeNames: { "#password": "password" },
                        ReturnValues: "UPDATED_NEW"
                    };
                    docClient.update(updateParams, function (err, data) {
                        if (err) {
                            console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                            var response = { message: 'Unable to update Password' };

                            callback(null, JSON.stringify(response));
                            return;

                        } else {
                            console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                            var response = { status_code: 200, message: 'Password updated successfully' };

                            callback(null, JSON.stringify(response));
                            return;
                        }
                    });
                }
            }
        });
    }
};

function listing_validation(event) {
    var response = {};
    var key = 'Error';
    response[key] = [];

    if (event.url === "") {
        response[key].push({ url: 'URL should not be empty' });
    }
    if (event.date === "") {
        response[key].push({ date: 'Date should not be empty' });
    }
    if (event.listing_status === "") {
        response[key].push({ listing_status: 'Status should not be empty' });
    }
    if (event.listing_level === "") {
        response[key].push({ listing_level: 'Level should not be empty' });
    }
    if (event.listing_template === "") {
        response[key].push({ listing_template: 'Template should not be empty' });
    }
    if (event.category1 === "") {
        response[key].push({ category1: 'Category 1 should not be empty' });
    }
    if (event.category2 === "") {
        response[key].push({ category2: 'Category 2 should not be empty' });
    }
    if (event.category3 === "") {
        response[key].push({ category3: 'Category 3 should not be empty' });
    }
    if (event.category4 === "") {
        response[key].push({ category4: 'Category 4 should not be empty' });
    }
    if (event.category5 === "") {
        response[key].push({ category5: 'Category 5 should not be empty' });
    }
    if (event.keywords === "") {
        response[key].push({ keywords: 'Keywords should not be empty' });
    }
    if (event.short_description === "") {
        response[key].push({ short_description: 'Short Description should not be empty' });
    }
    if (event.long_description === "") {
        response[key].push({ long_description: 'Long Description should not be empty' });
    }
    if (event.listing_keywords === "") {
        response[key].push({ listing_keywords: 'Listing Keywords should not be empty' });
    }
    if (event.facebook === "") {
        response[key].push({ facebook: 'Facebook should not be empty' })
    }
    if (event.twitter === "") {
        response[key].push({ twitter: 'Twitter should not be empty' })
    }
    if (event.instagram === "") {
        response[key].push({ instagram: 'Instagram should not be empty' })
    }
    if (event.linkedin === "") {
        response[key].push({ linkedin: 'Linkedin should not be empty' })
    }
    return response;
}

module.exports.addListing = (event, context, callback) => {

    var postdata = event['body'];

    var response = listing_validation(postdata)

    if (response.Error.length > 0) {
        callback(null, response);
        return;
    }

    var docClient = new AWS.DynamoDB.DocumentClient();

    var params = {
        TableName: LISTINGTABLE
    }

    docClient.scan(params, onScan);

    function onScan(err, itemCollection) {
        if (err) {

            console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));

        } else {

            var totalrecords = itemCollection.Items.length;
            var last_id = 0;
            var new_id;
            if (totalrecords > 0) {
                // print all the movies
                console.log("Scanning DONE.");
                var useritems = sortByKey(itemCollection.Items, 'listing_id');
                //console.log(useritems);

                var lastitem = useritems.pop()
                last_id = lastitem.listing_id
            }
            new_id = last_id + 1


            var item = {
                'listing_id': new_id,
            };

            for (var attributename in postdata) {
                if (postdata[attributename].length > 0) {
                    item[attributename] = [];
                    item[attributename] = postdata[attributename]
                }
            }

            //Put Item to DynamoDB
            console.log("Adding a new Listing...");

            var params = {
                TableName: LISTINGTABLE,
                Item: item
            };

            docClient.put(params, function (err, data) {
                if (err) {
                    console.error("Unable to add Listing. Error JSON:", JSON.stringify(err, null, 2));
                    response = {
                        Error: 'Listing is not saved successfully'
                    }
                    callback(null, JSON.stringify(response));
                    return;

                } else {
                    console.log("Added Listing:", JSON.stringify(item, null, 2));
                    response = {
                        status_code: 200,
                        message: 'Listing is saved successfully'
                    }
                    callback(null, JSON.stringify(response));
                    return;
                }
            });
        }
    }
}
module.exports.test = (event, context, callback) => {
    var response = {
        status_code: 200,
        result: event['body']
    }
    callback(null, JSON.stringify(response));
}

module.exports.list = (event, context, callback) => {
    // fetch all task from the database
    var docClient = new AWS.DynamoDB.DocumentClient();
    var params = {
        TableName: TASKTABLE
    }
    docClient.scan(params, (error, result) => {
        // handle potential errors
        if (error) {
            console.error(error);
            callback(null, {
                statusCode: error.statusCode || 501,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Couldn\'t fetch the task.',
            });
            return;
        }

        // create a response
        const response = {
            statusCode: 200,
            body: result.Items,
        };
        callback(null, response);
    });
};

module.exports.create = (event, context, callback) => {
    console.log(event);
    const timestamp = new Date().getTime();
    const data = event.body;
    console.log(data);
    if (typeof data.name !== 'string') {
        console.error('Validation Failed');
        callback(null, {
            statusCode: 400,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Couldn\'t create the task item.',
        });
        return;
    }

    var docClient = new AWS.DynamoDB.DocumentClient();

    const params = {
        TableName: TASKTABLE,
        Item: {
            id: uuid.v1(),
            name: data.name,
            companyname: data.companyname,
            priority: data.priority,
            tstatus: data.tstatus,
            createdAt: timestamp,
            updatedAt: timestamp,
        },
    };

    // write the todo to the database
    docClient.put(params, (error) => {
        // handle potential errors
        if (error) {
            console.error(error);
            callback(null, {
                statusCode: error.statusCode || 501,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Couldn\'t create the task item.',
            });
            return;
        }

        // create a response
        const response = {
            statusCode: 200,
            body: JSON.stringify(params.Item),
        };
        callback(null, response);
    });
};

module.exports.update = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log(event);
    const data = event.body;

    // validation
    if (typeof data.name !== 'string') {
        console.error('Validation Failed');
        callback(null, {
            statusCode: 400,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Couldn\'t update the task item.',
        });
        return;
    }

    var docClient = new AWS.DynamoDB.DocumentClient();

    const params = {
        TableName: TASKTABLE,
        Key: {
            id: event.path.id,
        },
        ExpressionAttributeNames: {
            '#todo_name': 'name',
        },
        ExpressionAttributeValues: {
            ':name': data.name,
            ':companyname': data.companyname,
            ':tstatus': data.tstatus,
            ':priority': data.priority,
            ':updatedAt': timestamp,
        },
        UpdateExpression: 'SET #todo_name = :name, companyname = :companyname,tstatus = :tstatus, priority = :priority, updatedAt = :updatedAt',
        ReturnValues: 'ALL_NEW',
    };

    // update the todo in the database
    docClient.update(params, (error, result) => {
        // handle potential errors
        if (error) {
            console.error(error);
            callback(null, {
                statusCode: error.statusCode || 501,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Couldn\'t fetch the task item.',
            });
            return;
        }

        // create a response
        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Attributes),
        };
        callback(null, response);
    });
};


module.exports.delete = (event, context, callback) => {
    console.log(event);
    const params = {
        TableName: TASKTABLE,
        Key: {
            id: event.path.id,
        },
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    // delete the todo from the database
    docClient.delete(params, (error) => {
        // handle potential errors
        if (error) {
            console.error(error);
            callback(null, {
                statusCode: error.statusCode || 501,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Couldn\'t remove the task item.',
            });
            return;
        }

        // create a response
        const response = {
            statusCode: 200,
            body: JSON.stringify({}),
        };
        callback(null, response);
    });
};


module.exports.testScraping = (event, context, callback) => {
    console.log(event);
    const data = event.body;
    var lambda = new AWS.Lambda();
    //Promisfy all method of lambda object with suffix Promisified
    PROMISE.promisifyAll(Object.getPrototypeOf(lambda), {
        suffix: "Promisified"
    });

    if (data.template === 'Single Page') {

    }
    else if (data.template === 'Singe Page with Pagination') {

    }
    else if (data.template === 'Multiple Page') {

    }
    else if (data.template === 'Multi Page with Location  Search') {

    }

    // var params = {
    //     FunctionName: 'backend-dev-saveScraping',
    //     InvocationType: 'RequestResponse',
    //     Payload: JSON.stringify(event, null, 2)
    // };
    // var resData = lambda.invokePromisified(params).then(function (response) {
    //     callback(null, response);
    // },function(err){
    //     callback(err, null);
    // });
    var p = new Promise(function (resolve, reject) {
        getAuth0Json(event, context).then(function (result) {
            resolve(result);
        }).catch(function (err) {
            reject(err);
        });
    }).then(function (result) {
        return new Promise((resolve, reject) => { // (*)
            CreateAuthToken(result).then(function (result) {
                resolve(result);
            }).catch(function (err) {
                reject(err);
            });
        });
    }).then(function (result) {
        console.log(result);
        context.done(null, result);
    }).catch(function (alert) {
        console.log(alert);
        context.done(alert, null);
    });
};


function getAuth0Json(event, context) {
    return new Promise(function (resolve, reject) {
        event.authJson = true;
        setTimeout(() => {
            resolve(event);
        }, 3000);
    });
}


function CreateAuthToken(authJson) {
    return new Promise(function (resolve, reject) {
        console.log('authJson: ' + authJson.authJson);
        setTimeout(() => {
            resolve(authJson);
        }, 3000);
    });
}

module.exports.saveScraping = (event, context, callback) => {
    console.log(event);
    const timestamp = new Date().getTime();
    const data = event.body;
    var docClient = new AWS.DynamoDB.DocumentClient();
    const params = {
        TableName: 'scraping',
        Item: {
            id: uuid.v1(),
            site_name: data.site_name,
            storeURL: data.storeURL,
            template: data.template,
            companyname: data.companyname,
            site_url: data.site_url,
            address: data.address,
            address2: data.address2,
            country: data.country,
            state: data.state,
            city: data.city,
            postcode: data.postcode,
            latitude: data.latitude,
            longtude: data.longtude,
            phone: data.phone,
            createdAt: timestamp,
            updatedAt: timestamp,
        },
    };

    // write the todo to the database
    docClient.put(params, (error) => {
        // handle potential errors
        if (error) {
            console.error(error);
            callback({
                statusCode: error.statusCode || 501,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Couldn\'t create the scrap item.',
            }, null);
            return;
        }

        // create a response
        const response = {
            statusCode: 200,
            body: params.Item,
        };
        callback(null, response);
    });
};